package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class InvoicePage {

	public WebDriver driver=null;
	//Constructor
	public InvoicePage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	By payOnArrival=By.xpath("//button[@class='btn btn-default arrivalpay']");
	By payNow=By.xpath("//button[@type='button'][contains(text(),'Pay Now')]");
	
	
	public void VerifyInvoiceDetail()
	{
		//Verify Invoice details
	}
	
	public void VerifyCustomerDetail()
	{
		//Verify Customer details
	}
	
	public void ConfirmPayment()
	{
		//confirm payment
	}
	
}	
