
package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HotelBookDetail {

	public WebDriver driver=null;
	//Constructor
	public HotelBookDetail(WebDriver driver)
	{
		this.driver=driver;
	}

	By emterFrstName=By.xpath("//input[@placeholder='First Name']");
	By enterLastName=By.xpath("//input[@placeholder='Last Name']");
	By enterEmail=By.xpath("//div[@class='col-md-5 col-xs-12']//input[@placeholder='Email']");
	By enterConfEmail=By.xpath("//input[@placeholder='Confirm Email']");
	By enterMobileNumber=By.xpath("//input[@placeholder='Contact Number']");
	By enterAddress=By.xpath("//input[@placeholder='Address']");
	By enterCountry=By.xpath("//a[@class='select2-choice']");
	By confirmBtn=By.xpath("//button[@name='guest']");
	
	public void FillBookForm(String firstName,String lastName,String email, String confEmail, String mobile,String address,String country )
	{
		driver.findElement(emterFrstName).sendKeys(firstName);
		driver.findElement(enterLastName).sendKeys(lastName);
		driver.findElement(enterEmail).sendKeys(email);
		driver.findElement(enterConfEmail).sendKeys(confEmail);
		driver.findElement(enterMobileNumber).sendKeys(mobile);
		driver.findElement(enterAddress).sendKeys(address);
		driver.findElement(enterCountry).sendKeys(country);
		driver.findElement(enterCountry).sendKeys(Keys.ENTER);
			
	}
	
	public WebElement Submit()
	{
		return driver.findElement(confirmBtn);
	}
	
	
	
	
	
	
	
	
}
