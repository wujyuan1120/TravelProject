package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomeSearchPage {

	public WebDriver driver=null;
	//Constructor
	public HomeSearchPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
	By searchHotels= By.xpath("//a[@title='Hotels']");
	By searchHoetlCityName=By.cssSelector("input.select2-input.select2-focused");
	By hotelInDateE=By.xpath("//div[@id='dpd1']//input[@placeholder='Check in']");
	By hotelOuDatE=By.xpath("//input[@placeholder='Check out']");
	By hotelTraveller=By.xpath("//input[@id='travellersInput']");
	By hotelSearch=By.xpath("//*[@id=\"hotels\"]/form/div[5]/button");
	
	
	By searchFlights= By.xpath("//a[@title='Flights']");
	By flighFromCity=By.xpath("//div[@id='s2id_location_from']//span[@class='select2-chosen'][contains(text(),'Enter City Or Airport')]");
	By flighToCity=By.xpath("//div[@id='s2id_location_to']//span[@class='select2-chosen'][contains(text(),'Enter City Or Airport')]");
	By flightDateDepart=By.xpath("//input[@placeholder='Depart']");
	By flightDateReturn=By.xpath("//input[@placeholder='Return']");
	By flightTraveller=By.xpath("//div[@class='col-md-1.form-group.go-right.col-xs-12']//input[@placeholder='0']");
    By flightRound=By.xpath("//label[@for='round']");
    By flightSingle=By.xpath("//label[@for='oneway']");
    By flightSearch=By.xpath("//div[@class='bgfade.col-md-3.col-xs-12.search-button']//button[@type='submit'][contains(text(),'Search')]");
	
	By searchTours=By.xpath("//a[@title='Tours']");
	By tourCityName=By.xpath("//span[contains(text(),'Search by Listing or City Name')]");
	By tourFromDate=By.xpath("//div[@id='tchkin']//input[@placeholder='Check in']");
	By tourTraveller=By.xpath("//select[@id='adults']");
	By tourType=By.xpath("//div[@id='s2id_tourtype']//a[@class='select2-choice']");
	By tourSearch=By.xpath("//div[@id='tours']//button[@type='submit'][contains(text(),'Search')]");
	
	
	public WebElement GetHotel()
	{
		
		return driver.findElement(searchHoetlCityName);
			
	}
	
	public void GetHotelCheckinDate(String hotelInDate, String hotlelInMonthYear)
	{
	    driver.findElement(hotelInDateE).click();
	    WebElement monthYear=driver.findElement(By.xpath("//div[9]//div[@class='datepicker-days']//table[1]//thead[1]//tr[1]//th[@class='switch']"));
	    while (!monthYear.getText().contains(hotlelInMonthYear))
	    {
	    	driver.findElement(By.xpath("//div[9]//div[@class='datepicker-days']//table[1]//thead[1]//tr[1]//th[@class='next']")).click();
	    	
	    }
		
		List<WebElement> dates=driver.findElements(By.className("day"));
		int count=dates.size();
		for (int i=0;i<count;i++)
		{
			String text=dates.get(i).getText();
			if(text.equalsIgnoreCase(hotelInDate))
			{
				driver.findElements(By.className("day")).get(i).click();
				break;
			}
		}
		
	}
	
	
	
		public void GetHotelCheckoutDate(String hotelOutDate, String hotlelOutMonthYear)
		{
		    driver.findElement(hotelOuDatE).click();
			
		    WebElement monthYear=driver.findElement(By.xpath("//div[9]//div[@class='datepicker-days']//table[1]//thead[1]//tr[1]//th[@class='switch']"));
		    while (!monthYear.getText().contains(hotlelOutMonthYear))
		    {
		    	driver.findElement(By.xpath("//div[9]//div[@class='datepicker-days']//table[1]//thead[1]//tr[1]//th[@class='next']")).click();
		    	
		    }
			
			List<WebElement> dates=driver.findElements(By.className("day"));
			int count=dates.size();
			for (int i=0;i<count;i++)
			{
				String text=dates.get(i).getText();
				if(text.equalsIgnoreCase(hotelOutDate))
				{
					driver.findElements(By.className("day")).get(i).click();
					break;
				}
			}
		}
		
		
		public void GetHotelTraveller()
		{
		driver.findElement(hotelTraveller).click();;
		}
		
		
		
		public void SearchHotel()
		{
			driver.findElement(hotelSearch).click();;
		}
		
		
		
		
}
			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	
	
	
	
	

