package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HotelPage 
{
	public WebDriver driver=null;
	//Constructor
	public HotelPage(WebDriver driver)
	{
		this.driver=driver;
	}
	

	By hotelName=By.xpath("//span[contains(text(),'Rendezvous Hotels')]");
	By roomType=By.xpath("//b[contains(text(),'Triple Rooms')]");
	By selectRoomType=By.xpath("//tbody//tr[1]//td[1]//div[2]//div[2]//div[1]//div[3]//div[1]//label[1]//div[1]");
	By bookNowBtn=By.xpath("//button[contains(text(),'Book Now')]");
	
	
	public void SelectRoom(String sRoomType)
	{
		if(roomType.toString()==sRoomType)
		{
			driver.findElement(By.xpath("//tbody//tr[1]//td[1]//div[2]//div[2]//div[1]//div[3]//div[1]//label[1]//div[1]")).click();
		}
		else
			
			System.out.println(sRoomType+" is not found.");
			
	}
	
	
	
	public WebElement SubmitHotelBook()
	{
		return driver.findElement(bookNowBtn);
	
	}
	
	
	
	
	
	
	
	
	
	
}
