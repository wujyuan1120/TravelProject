package PhpTtravels;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import PageObjects.HomeSearchPage;
import PageObjects.HotelBookDetail;
import PageObjects.HotelPage;
import Resources.Base;

public class BookHotelTest extends Base{

	
	
	@Test
	public void HomePageNavigation() throws IOException, InterruptedException
	{
		driver=InitializeDriver();
		driver.get(prop.getProperty("urlHomePage"));
		//Verify Website
		AssertJUnit.assertEquals(driver.getTitle(), prop.getProperty("siteName"));
		AssertJUnit.assertEquals(driver.getCurrentUrl(), prop.getProperty("urlHomePage"));
		   driver.findElement(By.xpath("//a[@title='Hotels']")).click();;
			driver.findElement(By.xpath("//span[contains(text(),'Search by Hotel or City Name')]")).click();
			HomeSearchPage searchHotel=new HomeSearchPage(driver);	
			searchHotel.GetHotel().sendKeys(prop.getProperty("hotelCityName"));
			Thread.sleep(2000);
			searchHotel.GetHotel().sendKeys(Keys.ENTER);	
			
			HomeSearchPage selectCheckInDate =new HomeSearchPage(driver);
			selectCheckInDate.GetHotelCheckinDate(prop.getProperty("hotelInDate"),prop.getProperty("hotlelInMonthYear"));
			
			HomeSearchPage selectCheckOutDate =new HomeSearchPage(driver);
			selectCheckOutDate.GetHotelCheckoutDate(prop.getProperty("hotelOutDate"),prop.getProperty("hotlelOutMonthYear"));
			
			HomeSearchPage findHotel=new HomeSearchPage(driver);
			findHotel.GetHotelTraveller();
			
			HomeSearchPage getHotel=new HomeSearchPage(driver);
			getHotel.SearchHotel();
			
			HotelPage submitHotelBook=new HotelPage(driver);
			submitHotelBook.SelectRoom(prop.getProperty("sRoomType"));
			submitHotelBook.SubmitHotelBook();
			
			
			HotelBookDetail confirmHotelBook=new HotelBookDetail(driver);
		    confirmHotelBook.FillBookForm(prop.getProperty("firstName"), prop.getProperty("lastName"), prop.getProperty("email"), prop.getProperty("confEmail"), prop.getProperty("mobile"), prop.getProperty("address"), prop.getProperty("country"));
		    confirmHotelBook.Submit().click();
		    driver.close();
		
		
	}
	
	
	
	/*@Test
	public void SelectHotelinDate()
	{   
		HomeSearchPage selectCheckInDate =new HomeSearchPage(driver);
		selectCheckInDate.GetHotelCheckinDate(prop.getProperty("hotelInDate"),prop.getProperty("hotlelInMonthYear"));
		
	}
	*/
	
	/*@Test
	public void SelectHoteloutDate()
	{
		HomeSearchPage selectCheckOutDate =new HomeSearchPage(driver);
		selectCheckOutDate.GetHotelCheckoutDate(prop.getProperty("hotelOutDate"),prop.getProperty("hotlelOutMonthYear"));
	}*/
	
	
	/*@Test
	public void SearchHotel() throws IOException
	{
		HomeSearchPage searchHotel=new HomeSearchPage(driver);
		searchHotel.GetHotelTraveller().click();
		searchHotel.SearchHotel().click();
	}*/
	
	/*@Test
	public void SubMitHotelBook()
	{
		HotelPage submitHotelBook=new HotelPage(driver);
		submitHotelBook.SelectRoom(prop.getProperty("sRoomType"));
		submitHotelBook.SubmitHotelBook();
	}
	*/
	
	/*@Test
	public void ConfirmHotelBook()
	{
		HotelBookDetail confirmHotelBook=new HotelBookDetail(driver);
	    confirmHotelBook.FillBookForm(prop.getProperty("firstName"), prop.getProperty("lastName"), prop.getProperty("email"), prop.getProperty("confEmail"), prop.getProperty("mobile"), prop.getProperty("address"), prop.getProperty("country"));
	    confirmHotelBook.Submit().click();
	    
	}
	*/

	
	
	
}
