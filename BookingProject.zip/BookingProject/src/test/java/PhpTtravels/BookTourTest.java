package PhpTtravels;
import org.testng.annotations.Test;

import Resources.Base;


public class BookTourTest extends Base{

	
	
	
	
	
	
	
	
	
	
	
}
