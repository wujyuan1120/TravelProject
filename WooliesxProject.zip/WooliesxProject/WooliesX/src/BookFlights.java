import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class BookFlights {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.phptravels.net/");
		
		// verify correct Website and URL
		Assert.assertEquals(driver.getTitle(), "PHPTRAVELS | Travel Technology Partner");
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.phptravels.net/");
		// book flights
		driver.findElement(By.xpath("//*[@id=\"body-section\"]/section/div[2]/div/div/div[2]/ul/li[2]")).click();
		//Thread.sleep(2000);
		// Add Delay
		driver.findElement(By.id("s2id_location_from")).click();
		WebElement departCity = driver.findElement(By.xpath("//div[@id='select2-drop']//input[@type='text']"));
		departCity.sendKeys("Hong");
		//Thread.sleep(2000);
		// Add Delay
		for (int i = 1; i <= 3; i++) {
			departCity.sendKeys(Keys.ARROW_DOWN);
		}
		departCity.sendKeys(Keys.ENTER);
		/*
		 * JavascriptExecutor js= (JavascriptExecutor)driver; String script =
		 * "return document.getElementById(\"s2id_location_from\").value;"; String text
		 * =(String) js.executeScript(script); System.out.println(text);
		 * while(text.equalsIgnoreCase("Hong Kong Intl (HKG)")
		 *  { i++;
		 * driver.findElement(By.xpath("//div[@id='select2-drop']//input[@type='text']")
		 * ).sendKeys(Keys.ARROW_DOWN); text =(String) js.executeScript(script);
		 * System.out.println(text);
		 * }
		 */
		/*
		 * JavascriptExecutor js= (JavascriptExecutor)driver; String script =
		 * "return document.getElementByXPath(\"//div[@id='select2-drop']//input[@type='text']\").value"
		 * ; String text =(String) js.executeScript(script);
		 */

		/*
		 * String text =(String) ((JavascriptExecutor)
		 * driver).executeScript("return arguments[0].value;",driver.findElement(By.
		 * xpath("//span[contains(text())]"))); System.out.println(text);
		 */
		driver.findElement(By.id("s2id_location_to")).click();
		WebElement arrCity = driver.findElement(By.xpath("//div[@id='select2-drop']//input[@type='text']"));
		arrCity.sendKeys("Sydney");
		//Thread.sleep(2000);
		arrCity.sendKeys(Keys.ARROW_DOWN);
		arrCity.sendKeys(Keys.ENTER);
		/*
		 * method for multiple radiobuttons int count =
		 * driver.findElements(By.xpath("\\input[@name='triptype']")).size(); for (int
		 * i=0; i<count;i++) { String
		 * triptype=driver.findElements(By.xpath("\\input[@name='triptype']")).get(i).
		 * getAttribute("value"); if(triptype=="oneway'") {
		 * //driver.findElements(By.xpath("\\input[@name='triptype']")).get(i).click();
		 * }
		 */
		driver.findElement(By.xpath("//label[@for='round']")).click();
		if (driver.findElement(By.xpath("//input[@placeholder='Return']")).getAttribute("required")
				.equalsIgnoreCase("true")) {
			System.out.println("Calander for Return Trip is enabled.");
			Assert.assertTrue(true);
		} else {
			System.out.println("Calander for Return Trip is disabled.");
			Assert.assertTrue(false);
		}
		
		
		
		/*explicit wait
		WebDriverWait d= new WebDriverWait(driver,20);
		d.until(ExpectedConditions.elementToBeClickable("")));
        */
		// if(driver.findElement(By.xpath("//input[@name='arrival']")).getAttribute("value").equalsIgnoreCase("required"))

		//Actions mouseAction=new Actions(driver);
		//mouseAction.moveToElement("").build().perform();
		
		
		
		
	}

}
