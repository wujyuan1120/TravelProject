
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;



import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class Calander {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.phptravels.net/");
		driver.findElement(By.xpath("//div[@id='dpd1']//input[@placeholder='Check in']")).click();;
		
	    WebElement monthYear=driver.findElement(By.xpath("//div[9]//div[@class='datepicker-days']//table[1]//thead[1]//tr[1]//th[@class='switch']"));
	    while (!monthYear.getText().contains("April 2020"))
	    {
	    	driver.findElement(By.xpath("//div[9]//div[@class='datepicker-days']//table[1]//thead[1]//tr[1]//th[@class='next']")).click();
	    	
	    }
		
		List<WebElement> dates=driver.findElements(By.className("day"));
		int count=dates.size();
		for (int i=0;i<count;i++)
		{
			String text=dates.get(i).getText();
			if(text.equalsIgnoreCase("24"))
			{
				driver.findElements(By.className("day")).get(i).click();
				break;
			}
		}
		

	}

}