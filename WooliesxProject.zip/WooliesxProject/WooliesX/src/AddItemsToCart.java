import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AddItemsToCart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Chromedriver.exe
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		// URL in the browser
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.ebay.com.au/");
		// validate Page Title
		System.out.println(driver.getTitle());
		// validate if landed on correct URL
		System.out.println(driver.getCurrentUrl());

		driver.findElement(By.xpath("//*[@id=\'gh-ac\']"))
				.sendKeys("Selenium Webdriver in Java: Learn with Examples by Salunke, MR Sa 9781495450204");
		
		//clink on links to another tab
		//String clickOnLink=Keys.chord(Keys.CONTROL,Keys.ENTER);
		//driver.findElement(By.xpath("")).sendKeys(clickOnLink);
		
		
		driver.findElement(By.xpath("//*[@id=\'gh-btn\']")).click();

	}

}
