import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.WebElement;

public class BookTravel {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.phptravels.net/");
		// verify correct Website and URL
		System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());
		// Book Tours
		driver.findElement(By.xpath("//*[@id=\'body-section\']/section/div[2]/div/div/div[2]/ul/li[3]/a")).click();
		//Thread.sleep(2000);
		driver.findElement(By.id("s2id_autogen10")).click();
		WebElement tour = driver.findElement(By.cssSelector("input.select2-input.select2-focused"));
		tour.sendKeys("Syd");
		Thread.sleep(2000);
		tour.sendKeys(Keys.ENTER);

		Select select = new Select(driver.findElement(By.id("adults")));
		Thread.sleep(1000L);
		// Add delays
		select.selectByValue("1");

	}

	private static void sleep(int i) {
		// TODO Auto-generated method stub

	}

}
