package Test;

public class TestClass1 {
@Test
public void test1()
{
	System.out.println("Hello");
	
}

@Test 
public void test2()
{
	System.out.println("Test2");
}


}