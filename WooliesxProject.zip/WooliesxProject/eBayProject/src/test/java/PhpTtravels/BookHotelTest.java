package PhpTtravels;

import java.io.IOException;

import org.testng.annotations.Test;

import Resources.Base;

public class BookHotelTest extends Base{

	@Test
	public void HomePageNavigation() throws IOException
	{
		driver=InitializeDriver();
		driver.get("https://www.phptravels.net/");
	}
	
}
