package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class EBayHomePage {

	public WebDriver driver;
	//Constructor
	public EBayHomePage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
	
	
	
	
	
}
