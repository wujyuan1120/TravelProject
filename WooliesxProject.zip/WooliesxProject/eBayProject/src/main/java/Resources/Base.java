package Resources;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.tools.ant.taskdefs.WaitFor.Unit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Base {
	
	public WebDriver driver;
	public WebDriver InitializeDriver() throws IOException
	{
		Properties prop=new Properties();
		FileInputStream file=new FileInputStream("C:\\Users\\Emma.Wu\\BookingProject\\src\\main\\java\\PhpTtravels\\Data.Properties");
		prop.load(file);
		String browserName=prop.getProperty("browser");
		if(browserName.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
			driver = new ChromeDriver();
			//execute in chome driver
		}
		else if (browserName.equals("firefox"))
		{
			//execute in firefox driver
		}
		else if (browserName.equals("IE"))
		{
			//execute in IE
		}
		
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
		return driver;
	}
	


}
