package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.Base;


public class eBayHomePage {
	
	public WebDriver driver=null;
	//Constructor
	public eBayHomePage(WebDriver driver)
	{
		this.driver=driver;
    }
	
By searchItem=By.xpath("//input[@placeholder='Search for anything']");



public WebElement SearchBookItem()
{
	return driver.findElement(searchItem);
}

}




