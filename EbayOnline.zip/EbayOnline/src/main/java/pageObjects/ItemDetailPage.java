package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ItemDetailPage {

	public WebDriver driver=null;
	//Constructor
	public ItemDetailPage(WebDriver driver)
	{
		this.driver=driver;
    }

	By itemTitle=By.xpath("//h1[@id='itemTitle']");
	By available=By.xpath("//span[contains(text(),'2 available')]");
	By quantity=By.xpath("//input[@id='qtyTextBox']");
	By addToCart=By.xpath("//a[@id='atcRedesignId_btn']");
	
	public WebElement ItemTitle()
	{
		return driver.findElement(itemTitle);
	}
			
	
	public WebElement Available()
	{
		return driver.findElement(available);
	}
	
	public WebElement Quantity()
	{
		return driver.findElement(quantity);
	}
	
	public WebElement AddToCart()
	{
	  return driver.findElement(addToCart);
	}
	
}