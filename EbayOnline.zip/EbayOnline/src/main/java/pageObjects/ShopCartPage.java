
package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.Base;


public class ShopCartPage {
	
	public WebDriver driver=null;
	//Constructor
	public ShopCartPage(WebDriver driver)
	{
		this.driver=driver;
    }

	By qty=By.cssSelector("#s1-10-odeo-au-1907907866-331659469404-qty[]-1-dropdown");
	By checkOutBtn=By.xpath("//button[contains(text(),'Go to checkout')]");
	
	public WebElement SelectQty()
	{
		return driver.findElement(qty);
	}
	
	public WebElement CheckOut()
	{
		return driver.findElement(checkOutBtn);
	}
	
	
}