package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ItemFoundPage {

	public WebDriver driver=null;
	//Constructor
	public ItemFoundPage(WebDriver driver)
	{
		this.driver=driver;
    }
	By bookName=By.xpath("//h3[@class='s-item__title']");
	
	
	public WebElement ItemFound()
	{
		return driver.findElement(bookName);
		
	}
	
	
	
	
	
	
	
	
}
