package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.Base;


public class AddedDialog {
	
	public WebDriver driver=null;
	//Constructor
	public AddedDialog(WebDriver driver)
	{
		this.driver=driver;
    }
	By btnGoToCart=By.xpath("//*[@id=\"atcRedesignId_overlay-atc-container\"]/div/div[1]/div/div[3]/a[2]");
	
	
	public WebElement ClickOnButton()
	{
		return driver.findElement(btnGoToCart);
	}
	
	
	
	
	
	
	
	
	
	
}