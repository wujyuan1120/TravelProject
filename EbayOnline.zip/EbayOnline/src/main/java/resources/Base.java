package resources;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.tools.ant.taskdefs.WaitFor.Unit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Base {
	
	public WebDriver driver=null;
	public Properties testData=null;
	public WebDriver InitializeDriver() throws IOException
	{
		Properties testData=new Properties();
		FileInputStream file=new FileInputStream("C:\\Users\\Emma.Wu\\EbayOnline\\src\\main\\java\\resources\\TestData.Properties");
		testData.load(file);
		
		String browserName=testData.getProperty("browser");
		if(browserName.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
			driver = new ChromeDriver();
			//execute in chome driver
		}
		else if (browserName.equals("firefox"))
		{
			driver = new FirefoxDriver();
			//execute in firefox driver
		}
		
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MICROSECONDS);
		driver.manage().window().maximize();
		return driver;
	}
	


}
