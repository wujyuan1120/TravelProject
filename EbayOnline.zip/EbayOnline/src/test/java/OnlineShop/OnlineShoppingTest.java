package OnlineShop;

import org.testng.annotations.Test;

import pageObjects.AddedDialog;
import pageObjects.ItemDetailPage;
import pageObjects.ItemFoundPage;
import pageObjects.ShopCartPage;
import pageObjects.eBayHomePage;
import resources.Base;

import org.testng.AssertJUnit;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class OnlineShoppingTest extends Base {


    @Test
	public void HomePage() throws IOException {
		driver= InitializeDriver();
		driver.get("https://www.ebay.com.au/");
		//verify landing on correct site
		AssertJUnit.assertEquals(driver.getCurrentUrl(),testData.getProperty("url"));
		AssertJUnit.assertEquals(driver.getTitle(), testData.getProperty("siteName"));
		//search Item
		eBayHomePage searchBook=new eBayHomePage(driver);
		searchBook.SearchBookItem().sendKeys(testData.getProperty("itemName"));
		driver.findElement(By.xpath("//input[@value='Search']")).click();
		//check if item found
		ItemFoundPage item=new ItemFoundPage(driver);
		if(item.ItemFound().getText()==testData.getProperty("itemName"))
		{
			item.ItemFound().click();
			System.out.println("Item is found.");
		}
		else
			System.out.println("Item is not found.");
	
		ItemDetailPage addItem=new ItemDetailPage(driver);
		AssertJUnit.assertEquals(addItem.ItemTitle().getText(), testData.getProperty("itemName"));
		
	    String avail=addItem.Available().getText();
	    if(avail.equalsIgnoreCase("2 available"))
	    {
	    	addItem.AddToCart();
	    }
	    else System.out.println("Not enough stock.");
	
	   AddedDialog goToCart=new AddedDialog(driver);
	   goToCart.ClickOnButton().click();
		
	    
		ShopCartPage shopCart=new ShopCartPage(driver);
		shopCart.SelectQty().click();
		int itemQtyDpBx= Integer.parseInt("2");
		for(int i=1;i<=itemQtyDpBx;i++)
		{
			shopCart.SelectQty().sendKeys(Keys.ARROW_DOWN);
		}
			
		shopCart.SelectQty().sendKeys(Keys.ENTER);
		
		shopCart.CheckOut().click();
		
		driver.close();
		
				
				
				
				
				
				
				
				
				
				
				
				
	}
		
		
				
		
		
		
}
	
	
